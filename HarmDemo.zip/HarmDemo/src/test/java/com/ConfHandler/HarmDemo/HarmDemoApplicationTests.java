package com.ConfHandler.HarmDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HarmDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
